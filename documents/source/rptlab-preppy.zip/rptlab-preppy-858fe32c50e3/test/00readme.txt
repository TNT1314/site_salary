Execute testall.py to run the tests.

This assumes you have a source distro or mercurial checkout,
and will try to place the directory above this on the path,
so that you are testing the preppy.py that goes with this suite.
