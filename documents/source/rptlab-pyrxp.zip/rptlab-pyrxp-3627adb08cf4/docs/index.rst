.. pyRXP documentation master file, created by
   sphinx-quickstart on Tue Mar 26 18:06:46 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyRXP: a Python wrapper for RXP
===============================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   installation
   usage
   examples
   roadmap
